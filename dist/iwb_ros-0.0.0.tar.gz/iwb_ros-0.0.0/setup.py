from setuptools import setup, find_packages

setup(
    name = "iwb_ros",
    version="0.0.0",
    author="Blackbird",
    author_email="jicong.ao@tum.de",
    description="IWB python package for milling machine simulation",
    license="MIT",
    package=find_packages(),
    classifiers=["Python 3.10", "Gitlab Project", "Ubuntu"],
    python_requires = ">=3.5",
)